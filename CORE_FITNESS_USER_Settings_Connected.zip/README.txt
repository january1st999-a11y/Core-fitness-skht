CORE FITNESS — HTML WEBSITE WITH UPI HANDOFF (TEST BUILD)

INCLUDED
- Responsive single-page HTML/CSS/JavaScript website.
- Four latest uploaded gym photographs in assets/gym-1.png through gym-4.png.
- Membership selection opens a checkout form and then launches a UPI payment intent.
- After attempting payment, member can open WhatsApp with a payment-verification message prefilled for trainer Shaik Farooq.
- Checkout distinguishes "New member" from "Existing member — renewal".

REQUIRED BEFORE UPI CAN WORK
1. Open index.html in a code editor.
2. Find: const GYM_UPI_ID = 'YOUR_UPI_ID_HERE';
3. Replace YOUR_UPI_ID_HERE with the actual merchant UPI ID, for example a valid VPA supplied by your bank/payment app. Do not use the example as your real ID.
4. Keep GYM_UPI_NAME as the displayed recipient name, and redeploy.

IMPORTANT PAYMENT LIMITATION
This static website cannot reliably know whether a UPI payment completed. Returning from a UPI app, clicking a button, or sending a WhatsApp message is NOT proof of payment. The flow therefore requests trainer verification and does not automatically mark a payment paid.
For real automatic payment confirmation, connect a payment provider or verified server-side payment confirmation/webhook to Supabase. Do not store secrets in this HTML file.

DEPLOY ON CLOUDFLARE PAGES
1. Extract the ZIP.
2. Upload the folder contents so index.html is at the deployment root and assets/ is beside it.
3. After changing the UPI ID, redeploy and test with a small amount or provider test mode where supported.
4. Check the UPI recipient name and amount before confirming a payment.

NOT YET INCLUDED
No real Supabase login/database writes, member records, admin dashboard, automatic paid marking, invoices, payment webhooks, or WhatsApp Business automation. WhatsApp is click-to-chat and the user must tap Send.


UPI CHECKOUT IMPORTANT
1. The configured UPI ID in index.html is 9160760355-2@ybl.
2. Before public launch, make a small test and confirm the payee name/amount shown in your UPI app before paying.
3. After payment, the member returns to the page and taps "I've Paid — Message Trainer on WhatsApp". This sends a prefilled request for the trainer to verify.
4. Static HTML cannot reliably know whether UPI payment succeeded, and it cannot safely mark a member as paid. The trainer must verify the bank/UPI record. For automatic verified updates, connect a backend/payment provider webhook and Supabase.
5. Do not put Supabase service-role keys or payment gateway secrets in index.html.


FIXES IN THIS BUILD
- Removed a duplicate checkout dialog and duplicate JavaScript declarations that caused a script SyntaxError and stopped buttons from working.
- Corrected gym photo URLs to match the uploaded JPEG file format.
- The membership plan buttons open one checkout dialog. The checkout form prepares the UPI payment intent and then enables the WhatsApp verification request.
- The page does not mark a payment as paid automatically; trainer verification is still required.

SUPABASE MEMBER LOGIN SETUP (UPDATED BUILD)

A. Configure the website
1. Open index.html in a text/code editor.
2. Find SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY near the start of the final script.
3. Replace PASTE_YOUR_SUPABASE_PROJECT_URL_HERE with your Supabase Project URL.
4. Replace PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE with the project's publishable/anon key.
5. NEVER use a service_role or secret key in this website file.
6. Upload the updated website folder to Cloudflare Pages and redeploy.

B. Apply these SQL additions in Supabase > SQL Editor > New query
Run this separately after the main CORE FITNESS database setup. This permits a signed-in member to create only their own member-role profile. It also creates a profile from signup metadata, including when email confirmation is enabled.

create policy "profiles_insert_own_member"
on public.profiles
for insert to authenticated
with check (id = (select auth.uid()) and role = 'member');

create or replace function public.handle_new_core_fitness_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, phone, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    new.raw_user_meta_data ->> 'phone',
    new.email,
    'member'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

revoke all on function public.handle_new_core_fitness_user() from public, anon, authenticated;

drop trigger if exists on_auth_user_created_core_fitness on auth.users;
create trigger on_auth_user_created_core_fitness
after insert on auth.users
for each row execute function public.handle_new_core_fitness_user();

C. Test sign-up/login
1. Open the deployed website.
2. Go to Member Sign Up / Login.
3. Sign up with an email address you can access, a phone number, and a password of at least 6 characters.
4. If Supabase email confirmation is enabled, confirm the email first.
5. Log in with that email and password. The panel displays profile, membership, payment and attendance records belonging to that signed-in account.

NOTES / SECURITY
- This ZIP contains placeholders for your Supabase URL and publishable key. It will not connect until you replace both values.
- The member dashboard only displays database records; it does not create membership, attendance or payment records automatically.
- Payment status is not automatically verified by UPI. Use a trusted payment provider and a secure server-side webhook before automatically marking a payment paid.
- Create the gym administrator in Supabase Authentication first, then add/update that user's profile role to admin using the SQL Editor as the database owner. Never let users set their own role to admin.
- Keep the Supabase database policies enabled. Never put a service-role/secret key in index.html.


PROFESSIONAL MEMBER PORTAL UPDATE
- Member sign-up/login now opens in a full-screen, mobile-friendly member portal.
- Updated authentication theme to a modern navy and mint style.
- Email signup confirmation redirects to the currently deployed website origin.
- Keep SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY configured in index.html.
- In Supabase Authentication > URL Configuration, set Site URL to your deployed Cloudflare Pages URL and allow that URL in Redirect URLs.
- This update does not configure a payment gateway or verify UPI payments.


PROFESSIONAL MEMBER PANEL UPDATE
- Member sign-up/login and account dashboard now use a full-page responsive layout.
- Adds a visible Supabase setup status label at the upper-left of the member panel.
- Email confirmation redirects to the current deployed website URL instead of localhost.
- The Supabase status label is accurate: it says "Supabase setup required" until valid credentials are configured.

IMPORTANT: Your actual Supabase Project URL and publishable key were not provided in this chat, so the HTML still contains placeholders. Open index.html and replace:
  PASTE_YOUR_SUPABASE_PROJECT_URL_HERE
  PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE
with your project's real URL and publishable key. Use only the publishable/anon key in browser HTML. NEVER put a secret/service_role key in the website.

After changing credentials, deploy the contents of core-fitness-html/ to your existing Cloudflare Pages project. In Supabase Authentication > URL Configuration, set Site URL to the public Cloudflare Pages URL and add that URL to Redirect URLs.


UNIQUE MEMBER ID SETUP (NEW)

Member IDs use the format CF-0001, CF-0002, CF-0003, etc. IDs are generated and stored in Supabase, not only in the browser. Run this SQL once in Supabase > SQL Editor > New query before testing the member panel. Back up your database first if it contains live member data.

-- 1. Add the permanent ID field and a sequence for new IDs
alter table public.profiles add column if not exists member_id text unique;
create sequence if not exists public.core_fitness_member_id_seq start 1;

-- 2. Assign IDs to existing profiles that do not have one
with numbered as (
  select id, row_number() over (order by created_at nulls first, id) as rn
  from public.profiles
  where member_id is null
)
update public.profiles p
set member_id = 'CF-' || lpad(numbered.rn::text, 4, '0')
from numbered
where p.id = numbered.id;

-- 3. Position the sequence after the IDs assigned above
select setval(
  'public.core_fitness_member_id_seq',
  greatest(coalesce((select max(regexp_replace(member_id, '^CF-', '')::bigint) from public.profiles where member_id ~ '^CF-[0-9]+$'), 0), 1),
  coalesce((select max(regexp_replace(member_id, '^CF-', '')::bigint) from public.profiles where member_id ~ '^CF-[0-9]+$'), 0) > 0
);

-- 4. Generate an ID automatically whenever a profile is inserted without one
create or replace function public.assign_core_fitness_member_id()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.member_id is null or btrim(new.member_id) = '' then
    new.member_id := 'CF-' || lpad(nextval('public.core_fitness_member_id_seq'::regclass)::text, 4, '0');
  end if;
  return new;
end;
$$;

drop trigger if exists assign_core_fitness_member_id_before_insert on public.profiles;
create trigger assign_core_fitness_member_id_before_insert
before insert on public.profiles
for each row execute function public.assign_core_fitness_member_id();

-- 5. Ensure the ID is unique (safe to run if the column was created above)
create unique index if not exists profiles_member_id_unique_idx on public.profiles(member_id) where member_id is not null;

After running the SQL, sign in to the user website and tap Refresh details. The member's ID appears under My Profile. Existing profiles receive IDs as part of the migration, and new profiles receive IDs automatically. IDs are permanent; do not edit them manually.

IMPORTANT LIMITATION
This uploaded ZIP is the member-facing website only. It does not contain your separate admin website, so it cannot add the ID column to that separate admin screen. To show the same IDs in the trainer/admin panel, that site must read the `member_id` field from the same Supabase `profiles` table and display it next to each member. Use the authenticated member's profile ID (`profiles.id`) as the relationship key for membership/payment/attendance data; `member_id` is a human-readable reference only.


ADMIN WEBSITE SETTINGS CONNECTION UPDATE
- The User Website now reads public.site_settings from the same Supabase project.
- It applies gym_name, trainer_name, location, morning_hours, evening_hours, monthly_fee, quarterly_fee, user_web_title, and user_web_message when available.
- Ensure the site_settings table has a SELECT policy for public website settings. This site does not write or modify settings.
- Deploy the ZIP contents with index.html at the root and assets/ beside it.
