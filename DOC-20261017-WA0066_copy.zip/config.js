/* Paste Supabase Project URL and publishable/anon public key here. NEVER use service_role/secret keys in browser code. */
window.CORE_FITNESS_CONFIG={SUPABASE_URL:"https://zcoxrjnuiiihcoazsozn.supabase.co",SUPABASE_ANON_KEY:"sb_publishable_gw4q7od7rOAD9qBBw78dKA_ngaQGp-k"};
