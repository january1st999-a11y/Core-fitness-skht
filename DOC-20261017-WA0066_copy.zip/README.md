# CORE FITNESS Admin Web — management UI update

## Setup on Android
1. Extract the archive.
2. Open `config.js` in a code editor.
3. Confirm the Supabase Project URL and publishable/anon public key are correct.
4. NEVER put a `service_role` key or secret key in browser code.
5. Deploy as a static site or connect the files to Cloudflare Pages.
6. Sign in with the Supabase Authentication owner account. The account must have `profiles.role = owner`.

## Added in this update
- Add, edit and delete controls for members, membership plans, payments, attendance, and expenses.
- Member entry form includes full name, phone, plan, start/expiry dates, payment status and amount paid.
- Plan creation form; manual payment and attendance forms; quick attendance check-in.
- Refresh/sync action for payment records.
- Website settings screen for gym name, trainer, timings and prices (currently schema-check only; see limitations).
- Mobile responsive layout.

## Important limitations — read before using
This is a browser-only admin UI connected to the existing Supabase project. Your exact database schema and RLS policies have not been verified in this session. The existing starter referenced `members`, but prior project work also used `profiles`, `memberships`, `invoices`, `payments`, `membership_plans`, `attendance`, and `gym_settings`; the real schema may differ. Add/edit/delete operations will only work where table names, columns, constraints, and owner RLS policies match. In particular, the member form contains the requested full set of fields, but the current submit handler removes plan/date/payment fields before inserting into `members` because the starter's member-table schema is not confirmed. Confirm and safely map the actual `profiles` + `memberships` schema before relying on member creation.

Automatic payments cannot be safely marked Paid merely because a user clicks a button or returns from a payment app. To auto-mark a payment as Paid, the user website must write to the same database and a trusted payment-provider webhook/server must verify the transaction before setting the payment status. This admin page's sync button only reloads the payment records; it does not verify UPI transactions. Automatic attendance requires a defined check-in rule/device/user flow; this update provides manual entry and quick check-in.

The Website settings form intentionally does not write unknown columns to `gym_settings`. To make edits from admin propagate to the public/member website, both sites must read/write the same verified settings schema. Do not disable RLS, expose service-role keys, or recreate/drop existing tables. Inspect the existing schema and policies first, then apply incremental changes and test with separate owner and member accounts.
