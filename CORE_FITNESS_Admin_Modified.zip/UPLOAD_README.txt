CORE FITNESS - Cloudflare Pages static upload

Upload the contents of this ZIP (index.html, styles.css, config.js, app.js) to the existing Cloudflare Pages project using Direct Upload.

The TypeScript file is a Supabase Edge Function source, not a website asset:
supabase/functions/member-admin/index.ts
Do not upload that file/folder as part of the Cloudflare Pages static site.

The SQL setup is separate:
supabase/setup.sql

Keep config.js public key as the Supabase publishable/anon key only. Never place a service_role/secret key in browser files.


LATEST PATCH NOTES
- Added a global Refresh all button in the header and improved its loading/error feedback.
- Added Website settings to navigation and a settings form backed by the site_settings key/value table.
- Added SITE_SETTINGS_SETUP.sql. Run it in Supabase SQL Editor before saving settings. The user website must also be updated to read site_settings; this admin ZIP cannot modify a separate user website that was not uploaded here. Never store secrets or payment gateway keys in site_settings.
- Fixed expense form to use description instead of the missing title column.
- Empty select fields now show “No records available” when their source list is empty.
- Member deletion still requires a deployed/configured member-admin Edge Function. This ZIP does not deploy Edge Functions.


MODIFIED SETTINGS PATCH
- Added editable User Website URL and an Open User Website link.
- Added second trainer fields (name, designation, optional phone). Defaults: yashwanth / Assistant Trainer.
- Added these keys to SITE_SETTINGS_SETUP.sql. Run the SQL in Supabase if the site_settings table has not been created yet. If the table already exists, this SQL is safe to run again and will not overwrite existing settings.
- The User Website must separately read the same site_settings table for settings to appear there; this ZIP modifies the Admin Website only.
