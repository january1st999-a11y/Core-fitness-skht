
/* CORE FITNESS Supabase Configuration */
window.CORE_FITNESS_CONFIG = {
  SUPABASE_URL: "https://qicoxrtjdxzzeonartnu.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_6L7pKFB_oJGtHAmFBzqaXg_JYv2xZb6"
};
