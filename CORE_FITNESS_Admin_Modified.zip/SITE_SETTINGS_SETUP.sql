-- CORE FITNESS shared website settings
-- Run in Supabase SQL Editor. Safe to run more than once.
create table if not exists public.site_settings (
  key text primary key,
  value text not null default '',
  updated_at timestamptz not null default now()
);
alter table public.site_settings enable row level security;
drop policy if exists "Authenticated admins can read site settings" on public.site_settings;
drop policy if exists "Authenticated admins can write site settings" on public.site_settings;
drop policy if exists "Public can read site settings" on public.site_settings;
-- Public read allows the member website to display gym info. Do not store secrets in this table.
create policy "Public can read site settings" on public.site_settings for select using (true);
-- Only owner/admin profiles can insert or update settings.
create policy "Authenticated admins can write site settings" on public.site_settings for all to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and lower(p.role) in ('owner','admin')))
with check (exists (select 1 from public.profiles p where p.id = auth.uid() and lower(p.role) in ('owner','admin')));
insert into public.site_settings(key,value) values
('gym_name','CORE FITNESS'),('trainer_name','Shaik Farooq'),('location','Srikalahasti, Andhra Pradesh'),
('morning_hours','6:00 AM – 12:00 PM'),('evening_hours','4:30 PM – 10:00 PM'),
('monthly_fee','1500'),('quarterly_fee','4000'),('user_web_title','CORE FITNESS'),('user_web_message','Welcome to CORE FITNESS'),
('user_web_url','https://corefitness-skht.january1st999.workers.dev/'),('trainer2_name','yashwanth'),('trainer2_designation','Assistant Trainer'),('trainer2_phone','')
on conflict (key) do nothing;
